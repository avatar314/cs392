//I pledge my honor that I have abided by the Stevens Honor System - atartagl

#ifndef LOG_H
#define LOG_H
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void logC(char* argv); 

#endif 