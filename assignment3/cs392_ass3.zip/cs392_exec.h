//I pledge my honor that I have abided by the Stevens Honor System - atartagl

#ifndef EXEC_H
#define EXEC_H
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>


void exec(char* argv[]);

#endif 