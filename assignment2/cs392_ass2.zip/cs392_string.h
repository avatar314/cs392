//I pledge my honor that I have abided by the Stevens Honor System - atartagl

#ifndef SORT_H
#define SORT_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void * cs392_memcpy (void *dst, void *src, unsigned num); 
unsigned cs392_strlen(char *str);


#endif 